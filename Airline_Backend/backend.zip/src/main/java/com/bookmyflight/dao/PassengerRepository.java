package com.bookmyflight.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bookmyflight.pojo.Passenger;


public interface PassengerRepository extends JpaRepository<Passenger, Integer> {

}
