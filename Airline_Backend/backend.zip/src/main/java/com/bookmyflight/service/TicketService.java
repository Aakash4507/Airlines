package com.bookmyflight.service;

public interface TicketService {
	
	void removeTicket(int ticket);

}
